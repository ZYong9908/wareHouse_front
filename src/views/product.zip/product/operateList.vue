<template>

</template>

<script>
export default {
  name: 'operateList',
}
</script>

<style scoped>

</style>
